# Shahriar Wallet — Preview Build

یک نسخه نمایشی قابل Build برای دیدن محیط و UX اپلیکیشن Shahriar.

## وضعیت
- RTL و فارسی
- Home / Assets / Activity / DApps / Settings
- Send / Receive / Swap UI
- حالت Preview با موجودی قابل تغییر از Settings
- انیمیشن و طراحی تیره با هویت Shahriar
- بدون کلید خصوصی، Seed، امضای تراکنش یا ارسال واقعی

**این نسخه عمداً Preview است و برای نگهداری پول واقعی نیست.** لایه بلاکچین و امضای واقعی باید جداگانه اضافه و تست امنیتی شود.

## Build
در GitHub، فایل workflow داخل `.github/workflows/android.yml` با Gradle 8.10.2 و Java 17 اجرا می‌شود و APK را به عنوان Artifact می‌سازد.

Local:
```bash
gradle assembleDebug
```
خروجی: `app/build/outputs/apk/debug/app-debug.apk`
