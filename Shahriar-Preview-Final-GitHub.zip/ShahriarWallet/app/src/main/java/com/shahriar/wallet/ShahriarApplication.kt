package com.shahriar.wallet

import android.app.Application

class ShahriarApplication : Application()
